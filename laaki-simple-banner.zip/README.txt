=== Laaki Simple Banner Control  ===
Contributors: lakhyap
Plugin URI:  https://webdesignvista.com/wordpress/plugins/laaki-simple-banner
Author URI: https://webdesignvista.com/
Author:  Lakhya Phukan
Donate link: https://webdesignvista.com/donate/laaki-simple-banner-plugin/
Tags: banner, ads, plugin
Requires at least: 5.0.0
Tested up to: 5.7.2
Requires PHP: 5.2.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows display of simple banners on widgetized areas of a wordpress installation 

== Installation ==

1. Download the zip 'laaki-simple-banner.zip'
2. Unzip the archive and upload the 'laaki-simple-banner' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to 'Widgets' menu in your Wordpres Dashboard to manage the settings

== Frequently Asked Questions ==

== Screenshots ==

1. Plugin Settings Page.

== Changelog ==

== Upgrade Notice ==

= Privacy Notices =

This plugin, does not:

* track users by stealth;
* write any user personal data to the database;
* send any data to external servers;
* use cookies.


= Support =

You can find detailed usage instructions and support for this plugin on  [Laaki Simple Banner](https://webdesignvista.com/wordpress/plugins/laaki-simple-banner). If you were unable to find the answer to your question on the page, make a comment below the post. I will reply at the earliest possible.